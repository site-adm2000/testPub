"nbm,bn.m/k'l/k"
print('sdghdfhdfh')
<<<<<<< HEAD
"klhklhklj;jl;"
'jklh;lkk'
=======
>>>>>>> parent of 7a6b721 (Update test-2.py)
